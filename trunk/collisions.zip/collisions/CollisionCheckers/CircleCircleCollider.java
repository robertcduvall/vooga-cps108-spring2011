package CollisionCheckers;

import java.util.ArrayList;

import shapes.Circle;

public class CircleCircleCollider 
{
	ArrayList<Circle> circles;
	
	public CircleCircleCollider(ArrayList<Circle> circles)
	{
		this.circles = circles;
	}
	
	
}

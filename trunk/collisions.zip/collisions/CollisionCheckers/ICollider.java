package CollisionCheckers;

public interface ICollider 
{

}

package shapes;

public interface Shape 
{
	public BoundingBox getBoundingBox();
	
	
}

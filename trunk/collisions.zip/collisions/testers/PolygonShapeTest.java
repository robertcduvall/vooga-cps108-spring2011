package testers;

import java.awt.Graphics;
import java.awt.geom.Line2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

import shapes.Circle;
import shapes.Polygon;
import shapes.Side;
import shapes.Vertex;

public class PolygonShapeTest extends JPanel
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("BasicPanel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);

        PolygonShapeTest panel = new PolygonShapeTest();
        frame.setContentPane(panel);          
        frame.setVisible(true);
	}
	
	public PolygonShapeTest()
	{
		super();
	}
	
	public void paintComponent(Graphics g)
	{
		System.out.println("painting");
        Vertex v1 = new Vertex(14,67);
        Vertex v2 = new Vertex(320, 189);
        Vertex v3 = new Vertex(156,0);
        Vertex v4 = new Vertex(178,78);
        
        Vertex[] vertices = {v1, v2, v3, v4};
        
//        Polygon newPoly = new Polygon(vertices);
//        
//		Side[] lines = newPoly.getSides();
//		
//		//for(Side side : lines)
//		//{
//		//	g.drawLine((int)side.v1.getX(), (int)side.v1.getY(), (int)side.v2.getX(), (int)side.v2.getY());
//		//}
//		
//		//g.drawRect((int)newPoly.getCenter().getX() - 5, (int)newPoly.getCenter().getY() - 5, 10, 10);
//		
//		//g.drawRect((int)newPoly.getBoundingBox().x, (int)newPoly.getBoundingBox().y, (int)newPoly.getBoundingBox().width, (int)newPoly.getBoundingBox().height);
//		
//		newPoly.move(50, 50);
//		lines = newPoly.getSides();
//		
//		for(Side side : lines)
//		{
//			g.drawLine((int)side.v1.getX(), (int)side.v1.getY(), (int)side.v2.getX(), (int)side.v2.getY());
//		}
//		//g.fillRect((int)newPoly.getCenter().getX() - 5, (int)newPoly.getCenter().getY() - 5, 10, 10);
//		
//		g.drawRect((int)newPoly.getBoundingBox().x, (int)newPoly.getBoundingBox().y, (int)newPoly.getBoundingBox().width, (int)newPoly.getBoundingBox().height);
//		
		
		Circle newCircle = new Circle(100, 0, 0);
		g.drawOval((int)newCircle.getX(), (int)newCircle.getY(), (int)newCircle.getWidth(), (int)newCircle.getHeight());
		g.fillRect((int)newCircle.getCenter().getX() - 5, (int)newCircle.getCenter().getY() - 5, 10, 10);
		//System.out.println(newCircle.getCenter().toString());
		
		newCircle.move(70, 60);
		g.drawOval((int)newCircle.getX(), (int)newCircle.getY(), (int)newCircle.getWidth(), (int)newCircle.getHeight());
		g.fillRect((int)newCircle.getCenter().getX() - 5, (int)newCircle.getCenter().getY() - 5, 10, 10);
	}
	
}
